<?php

namespace Plugin\StockShow4;

use Eccube\Event\TemplateEvent;
use Plugin\StockShow4\Repository\StockShowConfigRepository;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class StockShowEvent  implements EventSubscriberInterface
{
    /**
     * @var StockShowConfigRepository
     */

     protected $configRepository;


     /**
      * ProductReview constructor.
      *
      *@param StockShowConfigRepository $configRepository
      */

    public function __construct(StockShowConfigRepository $configRepository)
    {
        $this->configRepository = $configRepository;
    }

   /**
     * 配列のキーはイベント名、値は呼び出すメソッド名です。
     *
     * @return array
     */


    

    public static function getSubscribedEvents()
    {
        return [
            'Product/detail.twig' => 'StockShowTwig',
        ];
    }

    /**
     * @param TemplateEvent $event
     */

    public function StockShowTwig(TemplateEvent $event){
        $twig = '@StockShow4/default/Product/sotck_show.twig';

        $event->addSnippet($twig);
        $config = $this->configRepository->get();
        $parameters = $event->getParameters();
        $parameters['StockQtyShow'] = $config->getSockQtyShow();
        $event->setParameters($parameters);
    }
}
