<?php

namespace Plugin\StockShow4;

use Doctrine\ORM\EntityManagerInterface;
use Eccube\Plugin\AbstractPluginManager;
use Plugin\StockShow4\Entity\StockShowConfig;
use Symfony\Component\DependencyInjection\ContainerInterface;


class PluginManager extends AbstractPluginManager{
    /**
     * プラグイン有効時の処理
     *
     * @param $meta
     * @param ContainerInterface $container
     */

    public function enable(array $meta, ContainerInterface $container){
        $em = $container->get('doctrine.orm.entity_manager');
        $config=$this->createConfig($em);
    }
     /**
     * プラグイン設定を追加
     * 
     * @param EntityManagerInterface $em
     */

    protected function createConfig(EntityManagerInterface $em){
        $config = $em->find(StockShowConfig::class, 1);
        if($config){
            return $config;
        }

        $config = new StockShowConfig();
        $config->setStockQtyShow(5);
        $em->persist($config);
        $em->flush($config);
        return $config;
    }
}

?>
