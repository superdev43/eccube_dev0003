<?php

namespace Plugin\StockShow4\Controller\Admin;

use Eccube\Controller\AbstractController;
use Plugin\StockShow4\Form\Type\Admin\StockShowConfigType;
use Plugin\StockShow4\Repository\StockShowConfigRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ConfigController extends AbstractController
{

    /**
     * @Route("/%eccube_admin_route%/stock_show4/config", name="stock_show4_admin_config")
     * @Template("@StockShow4/admin/config.twig")
     * 
     * @param Request $request
     * @param StockShowConfigRepository $configRepository
     * 
     * @return array
     */

    public function index(Request $request, StockShowConfigRepository $configRepository)
    {
        $config = $configRepository->get();

        $form = $this->createForm(StockShowConfigType::class, $config);

        $form->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid()) {
            $config = $form->getData();
            $this->entityManager->persist($config);
            $this->entityManager->flush($config);

            log_info('Stock show config', ['status' => 'Success']);
            $this->addSuccess('登録しました。', 'admin');
            return $this->redirectToRoute('stock_show4_admin_config');
        }
        return [
            'form' => $form->createView(),
        ];
    }
}

