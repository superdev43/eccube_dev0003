<?php

namespace Plugin\StockShow4\Tests\Web;

use Faker\Generator;
use Symfony\Component\HttpKernel\Client;
use Symfony\Component\DomCrawler\Crawler;
use Eccube\Tests\Web\Admin\AbstractAdminWebTestCase;

?>